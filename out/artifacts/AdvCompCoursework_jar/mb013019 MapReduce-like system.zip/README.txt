To run this jar please place the data files in the same directory as the .jar.
I have provided the data files in the /Data, drag and drop the .jar into the file and then double click the jar to run.
Alternatively just make sure the data files are in the same directory as it and run the .jar

They should be named "AComp_Passenger_data.csv" and "Top30_airports_LatLong.csv".

This will generate "ObjectiveOne.txt", "ObjectiveTwo.txt" and "ObjectiveThree.txt".
It will also generate "errorlogs.txt" in the same place.